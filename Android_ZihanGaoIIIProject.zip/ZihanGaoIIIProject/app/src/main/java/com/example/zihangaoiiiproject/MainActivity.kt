package com.example.zihangaoiiiproject

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    // RFCOMM / SPP UUID
    private val sppUUID: UUID =
        UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private var btAdapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null

    private lateinit var txtStatus: TextView
    private lateinit var listView: ListView
    private lateinit var btnScan: Button
    private lateinit var btnConnectPaired: Button
    private lateinit var btnTestSend: Button

    // 扫描数据
    private val foundDevices = mutableListOf<BluetoothDevice>()
    private val foundNames = mutableListOf<String>()
    private var discoveryReceiver: BroadcastReceiver? = null

    // 运行时权限申请
    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* 授权结果回调后由用户再次点击操作触发 */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Edge-to-edge（保留你的）
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        // 获取 BluetoothAdapter（推荐方式）
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        btAdapter = manager.adapter

        // 绑定 UI
        txtStatus = findViewById(R.id.txtStatus)
        listView = findViewById(R.id.listDevices)
        btnScan = findViewById(R.id.btnScan)
        btnConnectPaired = findViewById(R.id.btnConnect)
        btnTestSend = findViewById(R.id.btnTestSend)

        // 按钮绑定
        btnScan.setOnClickListener { startScan() }
        btnConnectPaired.setOnClickListener { connectToPairedHC05() }
        btnTestSend.setOnClickListener { sendCmd("connected\n") }

        findViewById<Button>(R.id.btnF).setOnClickListener { sendCmd("F") }
        findViewById<Button>(R.id.btnB).setOnClickListener { sendCmd("B") }
        findViewById<Button>(R.id.btnL).setOnClickListener { sendCmd("L") }
        findViewById<Button>(R.id.btnR).setOnClickListener { sendCmd("R") }
        findViewById<Button>(R.id.btnS).setOnClickListener { sendCmd("S") }

        // 列表点击：选中设备后尝试连接
        listView.setOnItemClickListener { _, _, position, _ ->
            val device = foundDevices.getOrNull(position) ?: return@setOnItemClickListener
            stopScan()
            connectToDevice(device)
        }

        // 启动时先请求一次权限（Android 12+）
        requestBtPermissionsIfNeeded()
    }

    // ---------- 权限工具 ----------
    private fun hasConnect(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
                ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.BLUETOOTH_CONNECT
                ) == PackageManager.PERMISSION_GRANTED

    private fun hasScan(): Boolean =
        Build.VERSION.SDK_INT < 31 ||
                ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.BLUETOOTH_SCAN
                ) == PackageManager.PERMISSION_GRANTED

    private fun requestBtPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val need = listOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            ).filter { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
            if (need.isNotEmpty()) {
                permLauncher.launch(need.toTypedArray())
            }
        }
    }

    // ---------- 扫描 ----------
    @SuppressLint("MissingPermission")
    private fun startScan() {
        val adapter = btAdapter
        if (adapter == null) {
            toast("本机不支持蓝牙"); return
        }
        if (!adapter.isEnabled) {
            toast("请先打开系统蓝牙"); return
        }
        if (!hasScan()) {
            requestBtPermissionsIfNeeded()
            toast("缺少扫描权限"); return
        }

        // 清空旧结果
        foundDevices.clear()
        foundNames.clear()
        listView.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1, foundNames
        )

        // 注册广播接收器
        if (discoveryReceiver == null) {
            discoveryReceiver = object : BroadcastReceiver() {
                @SuppressLint("MissingPermission")
                override fun onReceive(context: Context?, intent: Intent?) {
                    when (intent?.action) {
                        BluetoothDevice.ACTION_FOUND -> {
                            val device: BluetoothDevice? =
                                intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                            device?.let { d ->
                                // 只展示经典蓝牙；HC-05 是经典蓝牙
                                val name = d.name ?: "Unknown"
                                val addr = d.address ?: ""
                                foundDevices.add(d)
                                foundNames.add("$name\n$addr")
                                (listView.adapter as ArrayAdapter<*>).notifyDataSetChanged()
                            }
                        }
                        BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                            toast("扫描结束")
                            txtStatus.text = "Status: Scan finished (${foundDevices.size} found)"
                        }
                    }
                }
            }
            registerReceiver(discoveryReceiver, IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            })
        }

        // 若还在扫描，先停掉
        if (adapter.isDiscovering) {
            @Suppress("MissingPermission")
            adapter.cancelDiscovery()
        }

        @Suppress("MissingPermission")
        val ok = adapter.startDiscovery()
        if (ok) {
            txtStatus.text = "Status: Scanning..."
            toast("开始扫描设备…点列表条目即可连接")
        } else {
            toast("启动扫描失败")
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        val adapter = btAdapter ?: return
        if (hasScan() && adapter.isDiscovering) {
            adapter.cancelDiscovery()
        }
    }

    // ---------- 连接：已配对的 HC-05/HC-06 ----------
    @SuppressLint("MissingPermission", "SetTextI18n")
    private fun connectToPairedHC05() {
        val adapter = btAdapter
        if (adapter == null) {
            toast("本机不支持蓝牙"); return
        }
        if (!adapter.isEnabled) {
            toast("请先打开系统蓝牙"); return
        }
        if (!hasConnect()) {
            requestBtPermissionsIfNeeded()
            toast("缺少连接权限"); return
        }

        val device: BluetoothDevice? = adapter.bondedDevices.firstOrNull { d ->
            val n = d.name.orEmpty()
            n.contains("HC-05", true) || n.contains("HC-06", true)
        }

        if (device == null) {
            txtStatus.text = "Status: Not Connected"
            toast("未找到已配对的 HC-05/06，请先在系统蓝牙里配对或使用扫描")
            return
        }
        connectToDevice(device)
    }

    // ---------- 连接：指定设备 ----------
    @SuppressLint("MissingPermission", "SetTextI18n")
    private fun connectToDevice(device: BluetoothDevice) {
        val adapter = btAdapter ?: return

        if (!hasConnect()) {
            requestBtPermissionsIfNeeded()
            toast("缺少连接权限"); return
        }

        txtStatus.text = "Status: Connecting to ${device.name ?: "Unknown"}..."
        thread {
            try {
                // 扫描时连接前，最好停止发现
                if (adapter.isDiscovering && hasScan()) {
                    @Suppress("MissingPermission")
                    adapter.cancelDiscovery()
                }

                val tmp = device.createRfcommSocketToServiceRecord(sppUUID)
                tmp.connect()

                socket = tmp
                out = tmp.outputStream

                runOnUiThread {
                    txtStatus.text = "Status: Connected to ${device.name ?: "Unknown"}"
                    toast("蓝牙连接成功")
                }
            } catch (e: SecurityException) {
                runOnUiThread {
                    txtStatus.text = "Status: Not Connected"
                    toast("连接失败：缺少权限（附近的设备/蓝牙连接）")
                }
            } catch (e: Exception) {
                closeSocket()
                runOnUiThread {
                    txtStatus.text = "Status: Not Connected"
                    toast("连接失败：${e.message}")
                }
            }
        }
    }

    // ---------- 发送命令 ----------
    private fun sendCmd(cmd: String) {
        val os = out
        if (os == null) {
            toast("尚未连接蓝牙")
            return
        }
        thread {
            try {
                os.write(cmd.toByteArray(Charsets.UTF_8))
                os.flush()
            } catch (e: Exception) {
                runOnUiThread { toast("发送失败：${e.message}") }
                closeSocket()
            }
        }
    }

    // ---------- 清理 ----------
    private fun closeSocket() {
        try { out?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        out = null
        socket = null
    }

    private fun toast(msg: String) =
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        stopScan()
        // 注销广播
        discoveryReceiver?.let {
            try { unregisterReceiver(it) } catch (_: Exception) {}
            discoveryReceiver = null
        }
        closeSocket()
        super.onDestroy()
    }
}

